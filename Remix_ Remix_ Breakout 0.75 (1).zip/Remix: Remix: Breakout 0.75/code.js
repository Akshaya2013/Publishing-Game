var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["ca9add18-11c9-46ab-b4e7-fad5c741334d","57071a23-7fdf-449d-937d-ab6270a59fe5","4893772d-a396-45ce-9de1-9e6427a149df"],"propsByKey":{"ca9add18-11c9-46ab-b4e7-fad5c741334d":{"name":"pick","sourceUrl":"assets/api/v1/animation-library/gamelab/jruDtidFMd1O6on6ZXw1aUUXYZ13Mp9c/category_tools/pick_diamond.png","frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":2,"version":"jruDtidFMd1O6on6ZXw1aUUXYZ13Mp9c","categories":["tools"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/jruDtidFMd1O6on6ZXw1aUUXYZ13Mp9c/category_tools/pick_diamond.png"},"57071a23-7fdf-449d-937d-ab6270a59fe5":{"name":"bg","sourceUrl":"assets/api/v1/animation-library/gamelab/kpGIKirow4l3xRdN_BYD7pW3aVlfysex/category_backgrounds/abstract_15.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"kpGIKirow4l3xRdN_BYD7pW3aVlfysex","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/kpGIKirow4l3xRdN_BYD7pW3aVlfysex/category_backgrounds/abstract_15.png"},"4893772d-a396-45ce-9de1-9e6427a149df":{"name":"abstract_16_1","sourceUrl":"assets/api/v1/animation-library/gamelab/OEa2gEbbvs2v84AZcjbUfOw_7tVqVKJr/category_backgrounds/abstract_16.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"OEa2gEbbvs2v84AZcjbUfOw_7tVqVKJr","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/OEa2gEbbvs2v84AZcjbUfOw_7tVqVKJr/category_backgrounds/abstract_16.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var bg=createSprite(200,200,400,400);
bg.setAnimation("bg");

var box1 = createSprite(25, 75, 50, 50);
box1.shapeColor="aqua";
var box2 = createSprite(75, 75, 50, 50);
box2.shapeColor="pink";
var box3 = createSprite(125, 75, 50, 50);
box3.shapeColor="aqua";
var box4 = createSprite(175, 75, 50, 50);
box4.shapeColor="pink";
var box5 = createSprite(225, 75, 50, 50);
box5.shapeColor="aqua";
var box6 = createSprite(275, 75, 50, 50);
box6.shapeColor="pink";
var box7 = createSprite(325, 75, 50, 50);
box7.shapeColor="aqua";
var box8 = createSprite(375, 75, 50, 50);
box8.shapeColor="pink";


var box9 = createSprite(25, 125, 50, 50);
box9.shapeColor="pink";
var box10 = createSprite(75, 125, 50, 50);
box10.shapeColor="aqua";
var box11 = createSprite(125, 125, 50, 50);
box11.shapeColor="pink";
var box12 = createSprite(175, 125, 50, 50);
box12.shapeColor="aqua";
var box13 = createSprite(225,125, 50, 50);
box13.shapeColor="pink";
var box14 = createSprite(275, 125, 50, 50);
box14.shapeColor="aqua";
var box15 = createSprite(325, 125, 50, 50);
box15.shapeColor="pink";
var box16 = createSprite(375, 125, 50, 50);
box16.shapeColor="aqua";

paddle=createSprite(200,370,100,20);
ball=createSprite(200,200,20,20);
 ball.setAnimation("pick")
ball.scale=0.5

//initilizing score
var score=0
var gameState="serve"

function draw() {
  background("white");
  
  //concatination + add more than one datatype together
 
 
  //Arithmetic Operators - < > * / + -
  // Realtional Operaters - > < = <= ===
  // Logical Operators - and " OR || NOT !=
  
  
  // compiler/interpreter
  
  createEdgeSprites();
 
  ball.bounceOff(rightEdge)
  ball.bounceOff(leftEdge)
  ball.bounceOff(topEdge)
  
  

 
 
 
 ball.bounceOff(paddle);
 
 

 if (ball.isTouching(box1)){
 score+=1
   box1.destroy()
 }

  if (ball.isTouching(box2)){
    score+=1
   box2.destroy()
 }

 if (ball.isTouching(box3)){
   score+=1
   box3.destroy()
 }

 if (ball.isTouching(box4)){
   score+=1
   box4.destroy()
 }
 
 if (ball.isTouching(box5)){
   score+=1
   box5.destroy()
 }
 
  if (ball.isTouching(box6)){
    score+=1
   box6.destroy()
 }
 
  if (ball.isTouching(box7)){
    score+=1
   box7.destroy()
 }
 
  if (ball.isTouching(box8)){
    score+=1
   box8.destroy()
 }
 
  if (ball.isTouching(box9)){
    score+=1
   box9.destroy()
 }
 
  if (ball.isTouching(box10)){
    score+=1
   box10.destroy()
 }
 
  if (ball.isTouching(box11)){
    score+=1
   box11.destroy()
 }
 
  if (ball.isTouching(box12)){
    score+=1
   box12.destroy()
 }
 
  if (ball.isTouching(box13)){
    score+=1
   box13.destroy()
 }
 
  if (ball.isTouching(box14)){
    score+=1
   box14.destroy()
 }
 
  if (ball.isTouching(box15)){
    score+=1
   box15.destroy()
 }
 
  if (ball.isTouching(box16)){
    score+=1
   box16.destroy()
 }
 

  drawSprites();
 textSize(20);
 fill("aqua")
  text("POINTS - "+ score,150,30)

  if(gameState==="serve") {
   text("PRESS ENTER TO START THE GAME",20,300);
   if (keyDown("enter")){
  ball.velocityX= 3;
  ball.velocityY= 3;
  gameState="play"
}
   
 }
  if(gameState==="play"){
     paddle.x = mouseX
     if(score===16 || ball.y>400){
       gameState="end"
     }
    
  }
  
  if(gameState==="end"){
    text("GAME OVER",150,200)
    ball.x=200;
    ball.y=200;
    ball.velocityX=0;
    ball.velocityY=0;
    paddle.visible=false;
    ball.visible=false;
  
    
  }
  
}




// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
